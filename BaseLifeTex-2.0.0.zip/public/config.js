const BASE_URL = "https://administrator.lifetex.vn:326/api/v1";
