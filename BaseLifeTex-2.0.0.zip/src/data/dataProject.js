export const listProject = [
    {
        status: "to do",
        _id: "67d246f1bf0422c295e3f5a5",
        name: "project1",
        description: "test project",
        managerId: {
            phone: "",
            _id: "67cf8ec2cd8a333c1eae0981",
            userName: "Nguyễn Văn A",
            email: "namkoj1507@gmail.com",
        },
        members: [],
        createdAt: "2025-03-13T02:46:09.732Z",
        updatedAt: "2025-03-13T02:46:09.732Z",
        __v: 0,
    },
];
