export default function AccessLayout({ children }) {
  return <div>{children}</div>;
}
