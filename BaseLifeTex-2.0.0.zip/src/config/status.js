export const STATUS_PROJECT = {
  PROGRESSING: 0,
  DONE: 1,
  ARCHIVED: 2,
};
