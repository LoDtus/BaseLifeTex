export const PRIORITY = [
  { value: 0, label: "Thấp" },
  { value: 1, label: "Trung bình" },
  { value: 2, label: "Cao" },
];
